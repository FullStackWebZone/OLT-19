# Dark-mode-button
I design a toggle button that switches between two modes, a dark mode and a light mode.
