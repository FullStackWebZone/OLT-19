# Animated-Dark-Mode-Toggle

A clone of the dark mode toggle on Google Fonts using Kevin Powell's [tutorial](https://www.youtube.com/watch?v=QtuLN0lNb-Y). Check it out [here](https://patel-priyank.github.io/Animated-Dark-Mode-Toggle/)!
